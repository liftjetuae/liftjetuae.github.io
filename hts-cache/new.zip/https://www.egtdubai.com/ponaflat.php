<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">

<head>
<title>Emmanuel General Trading</title>

<link rel="stylesheet" type="text/css" href="style.css">
<style TYPE="text/css">
	<!--
	a {text-decoration: none;}
a:link {font-size: 12px; color: #0099FF; font-family :  verdana, times new roman,  arial,helvetica,sans-serif; font-weight:none; line-height:19px; letter-spacing:1px;}
a:visited {font-size: 12px; color: #0099FF; font-family : verdana, times new roman, arial,helvetica,sans-serif; font-weight:none; line-height:19px; letter-spacing:1px;}
a:hover {font-size: 12px; color: #66FFFF; font-family :  verdana, times new roman,  arial,helvetica,sans-serif; font-weight:none; line-height:19px; letter-spacing:1px; }
a:active {font-size: 12px; color: #0099FF; font-family :  verdana, times new roman,   arial,helvetica,sans-serif; font-weight:none; line-height:19px;  letter-spacing:1px;}

      -->
</style>
<script language="JavaScript" src="mouseover.js"></script>
<script type="text/javascript">
function inputFocus(i){
if(i.value==i.defaultValue){ i.value=""; i.style.color="#888"; }
}
function inputBlur(i){
if(i.value==""){ i.value=i.defaultValue; i.style.color="#888"; }
}
</script>
<script type="application/javascript">

 function isNumberKey(evt)
     {
        var charCode = (evt.which) ? evt.which : event.keyCode
         if (charCode > 31 && (charCode < 48 || charCode > 57))
            return false;

         return true;
     }

</script>
<script type="text/javascript" src="lib/jquery-1.4.2.min.js"></script>
<!--
  jCarousel library
-->
<script type="text/javascript" src="lib/jquery.jcarousel.min.js"></script>
<!--
  jCarousel skin stylesheet
-->
<link rel="stylesheet" type="text/css" href="skins/tango/skin.css" />
<script language="JavaScript" src="gen_validatorv3.js"></script>
<script type="text/javascript" async="" src="ga.js"></script>
<link rel="stylesheet" href="css/reset.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/style.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/grid.css" type="text/css" media="screen">
<link rel="stylesheet" href="css/superfish-menu.css" type="text/css" media="screen">
<script type="text/javascript" src="js/html5.js"></script>
<script type="text/javascript" src="js/jquery-1.6.min.js" ></script>
<script type="text/javascript" src="js/FF-cash.js" ></script>
<script type="text/javascript" src="js/hoverIntent.js"></script>
<script type="text/javascript" src="js/superfish.js"></script>
<script type="text/javascript" src="js/cufon-yui.js"></script>
<script src="js/jquery.easing.1.3.js" type="text/javascript"></script>
 <script src="js/tms-0.3.js" type="text/javascript"></script>
 <script src="js/tms_presets.js" type="text/javascript"></script>  
 <script>			$(function(){				$('.box4').hover(function(){					$(this).find(".m1").stop().animate({top:-143}, "normal")				}, function(){					$(this).find(".m1").stop().animate({top:0}, "normal")				});			})		</script>              <!--[if lt IE 7]>  		<div style=' clear: both; text-align:center;  padding:0 0 0 0px; position: relative;'>			<a href="http://www.microsoft.com/windows/internet-explorer/default.aspx?ocid=ie6_countdown_bannercode"><img src="http://www.theie6countdown.com/images/upgrade.jpg" border="0"  alt="" /></a>		</div>   <![endif]--></head>

<body  class=bodybg  topmargin="0" marginwidth="0" marginheight="0" leftmargin="0">





<!###########################################################################################>
<!-------------------------------top bg starts------------------------------------------><div align="center">
 <center>
  <table width="100%" height="10" cellspacing="0" cellpadding="0" border="0" class=white>
   <tr>
    <td width="100%" height="10" valign="top"  align="left"><!-------------------------------logo name and links starts------------------------------------------><div align="center">
 <center>
  <table width="1190" height="77" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="121" height="77" valign="top"  align="left"></td>
    <td width="1069" height="77" valign="top"  align="right" STYLE="background-image: url(topbg.jpg); background-position: bottom center; bgproperties: fixed; background-repeat:no-repeat"><!-------------------------------logo name and links starts------------------------------------------><div align="left">
  <table width="948" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="660" height="10" valign="top"  align="left"></td>
	 <td width="139" height="10" valign="top"  align="left"><a href="Emmanuel_General_Trading_Brochure.pdf" target="_blank"><img src="egtbrochure.gif" width="139" height="20" border="0"></a></td>
	  <td width="10" height="10" valign="top"  align="left"></td>
	    <td width="139" height="10" valign="top"  align="left"><a href="http://www.egtdubai.com/"><img src="egt.gif" width="139" height="20" border="0"></a></td>
	  
		
	   </tr>

  </table>
 </center>
</div>
<!-------------------------------logo name and links endss---------------------------------------></td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------logo name and links endss---------------------------------------></td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------top bg endss--------------------------------------->
<!###########################################################################################>


<!###########################################################################################>
<!-------------------------------logo name and links starts------------------------------------------><div align="center">
 <center>
  <table width="100%" height="90" cellspacing="0" cellpadding="0" border="0" STYLE="background-image: url(bgbar1.jpg); background-position: bottom center; bgproperties: fixed; background-repeat:repeat-x">
   <tr>
    <td width="100%" height="10" valign="top"  align="left"><!-------------------------------logo name and links starts------------------------------------------><div align="center">
 <center>
  <table width="948" height="90" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="948" height="90" valign="top"  align="left"><!-------------------------------logo name and links starts------------------------------------------><div align="center">
 <center>
  <table width="948" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="322" height="90" valign="top"  align="left"><a href="index.php"><img src="logo.jpg" width="322" height="90" border="0"></a></td>
    <td width="626" height="90" valign="top"  align="right"  STYLE="background-image: url(rightbg.jpg); background-position: bottom center; bgproperties: fixed; background-repeat:repeat-x"><!#############################################################################################################################>
<!------------------------------------------------------lnks starts------------------------------------------------------------>
<div align="RIGHT">
 <table border="0" width="463" height="20" cellspacing="0" cellpadding="0">
  <tr>
     <td width="115" height="49" valign="top" align="center"><a href="index.php" onmouseout="di('npanel1','panel1'); return false;"onmouseover="di('npanel1','panel11');return false;"><img src="link1.jpg" width="115" height="49" border="0" name="npanel1" ></a></td>
     <td width="1" height="49" valign="top" align="center" background="linkline.jpg"><!------gap---></td>
   <td width="115" height="49" valign="top" align="center"><a href="aboutus.php" onmouseout="di('npanel2','panel2'); return false;"onmouseover="di('npanel2','panel22');return false;"><img src="link2.jpg" width="115" height="49" border="0" name="npanel2" ></a></td>
 
     <td width="1" height="49" valign="top" align="center"  background="linkline.jpg"><!------gap---></td> 
   <td width="115" height="49" valign="top" align="center"><a href="products.php" onmouseout="di('npanel3','panel3'); return false;"onmouseover="di('npanel3','panel33');return false;"><img src="link3_.jpg" width="115" height="49" border="0"></a></td>
 
     <td width="1" height="49" valign="top" align="center"  background="linkline.jpg"><!------gap---></td>
   <td width="115" height="49" valign="top" align="center"><a href="contactus.php" onmouseout="di('npanel4','panel4'); return false;"onmouseover="di('npanel4','panel44');return false;"><img src="link4.jpg" width="115" height="49" border="0" name="npanel4" ></a></td>
 
  </tr>
 </table>
</div>
<!------------------------------------------------------lnks Ends------------------------------------------------------------>
<!#############################################################################################################################>
</td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------logo name and links endss---------------------------------------></td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------logo name and links endss---------------------------------------></td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------logo name and links endss--------------------------------------->
<!###########################################################################################>






<!###########################################################################################>
<!-------------------------------banner starts------------------------------------------><div align="center">
 <center>
  <table width="100%" height="246" cellspacing="0" cellpadding="0" border="0" STYLE="background-image: url(bg3.jpg); background-position: bottom center; bgproperties: fixed; background-repeat:repeat-x">
  
   <tr>
    <td width="100%" height="10" valign="top"  align="left"><!-------------------------------logo name and links starts------------------------------------------><div  align="center">
  <center>
  <table border="0" width="948" height="10" cellspacing="0" cellpadding="0"  > 
    <tr>
          <td width="948" height="240" align="top" align="center"><!-- header --><!-- <div class="bg">--><header><div class="container_12">                 
                  <div class="slider"><ul class="items">
				  <li><img src="images/ponaflex_02.jpg" alt=""></li>
				
				  
                  </ul></div>	
                  </div></header><!-- </div>--> 
				  <script type="text/javascript">	
				  $(function()
				  {		$('.slider')._TMS({			
				  prevBu:'.prev',			
				  nextBu:'.next',			
				  playBu:'.play',			
				  duration:888,			
				  easing:'none',			
				  preset:'diagonalExpand',			
				  pagination:true,			
				  slideshow:6000,			
				  numStatus:false,			
				  banners:true,		
				  bannerMeth:'custom',			
				  bannerShow:function(banner)
				  {	banner	.hide()	.fadeIn(1200)} ,			
				  bannerHide:function(banner){banner .show()	.fadeOut(1200)},
				  progressBar:'<div class="progbar"></div>'})	})	
				  </script>             	
				  <script type="text/javascript"> 
				  var _gaq = _gaq || [];  
				  _gaq.push(['_setAccount', 'UA-7078796-5']);  
				  _gaq.push(['_trackPageview']);  (function() {  
				  var ga = document.createElement('script');
				  ga.type = 'text/javascript'; ga.async = true;   
				  ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';    
				  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);  })();
				  </script>
				  </td>
    </tr>
				
  </table>
  </center>
</div>
<!-------------------------------logo name and links endss---------------------------------------></td>
   </tr>
  </table>
 </center>
</div>
<!------------------------------banner endss--------------------------------------->
<!###########################################################################################>


<!###########################################################################################>
<!-------------------------------logo name and links starts------------------------------------------><div align="center">
 <center>
  <table width="100%" height="1" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="100%" height="1" valign="top"  align="left"  class=blue></td>
   </tr>
   <tr>
    <td width="100%" height="18" valign="top"  align="left"  class=dblue></td>
   </tr>
   <tr>
    <td width="100%" height="1" valign="top"  align="left"  class=blue></td>
   </tr>
   <tr>
    <td width="100%" height="2" valign="top"  align="left"  class=dblue></td>
   </tr>
   <tr>
    <td width="100%" height="2" valign="top"  align="left"  class=white></td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------logo name and links endss--------------------------------------->
<!###########################################################################################><!###########################################################################################>
<!-------------------------------table starts----------------------------------------------->
<div align="center">
 <center>
  <table width="100%" height="10" cellspacing="0" cellpadding="0" border="0" STYLE="background-image: url(middlebg.jpg); background-position: top center; bgproperties: fixed; background-repeat:repeat">
   <tr>
    <td width="100%" height="200" valign="top"  align="left">
<!###########################################################################################>
<!-------------------------------middle portion shadow starts------------------------------------------><div align="center">
 <center>
  <table width="1004" height="100" cellspacing="0" cellpadding="0" border="0"  STYLE="background-image: url(middlebotbg.png); background-position: bottom center; bgproperties: fixed; background-repeat:no-repeat">
   <tr>
    <td width="1004" height="10" valign="top"  align="left"><div align="center">
<center>
<table width="948" height="10" cellspacing="0" cellpadding="0" border="0" class=white>
<tr>
<td width="20" height="10" valign="top" align="right"></td>
<td width="908" height="10" valign="top" align="right"></td>
<td width="20" height="10" valign="top" align="right"></td>
</tr>
<tr>
<td width="20" height="10" valign="top" align="right"></td>
<td width="908" height="10" valign="top" align="right"><font class="tgray">You are in � </font><a href="products.php"><font class="tgray">Products </a>� </font> <a href="products.php"><font class="tgray">
Ponaflex</a> �</font><font class="tgray">
Ponaflat Standard Duty Layflat Hose</font></td>
<td width="20" height="10" valign="top" align="right"></td>
</tr>
</table>
</center>
</div></td>
   </tr>
   <tr>
    <td width="1004" height="10" valign="top"  align="left"><!----------------------dont touch the above code starts--------------------->
<!###########################################################################################>
<!-------------------------------logo name and links starts------------------------------------------><div align="center">
 <center>
  <table width="948" height="500" cellspacing="0" cellpadding="0" border="0" class=white>
   <tr>
    <td width="948" height="10" valign="top"  align="center">
<!###########################################################################################>
<!-------------------------------logo name and links starts------------------------------------------><div align="center">
 <center>
  <table width="908" height="100" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="908" height="20" valign="top"  align="left" ><!----------top gap---------></td>
   </tr> 
   <!------------------------working space starts here------------------>
   
   <!------------------dont touch above code------------------------->
   <tr>
    <td width="908" height="10" valign="top"  align="left" ><img src="ponaflatheading.gif" width="500" height="20" border="0"></td>
   </tr> 
   <tr>
    <td width="908" height="10" valign="top"  align="left" ><!---------- gap---------></td>
   </tr>
   <tr>
    <td width="908" height="3" valign="top"  align="left" background="bgline.gif" ><!---------- gap---------></td>
   </tr>
   
   <!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%1st prodtuct starts%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%>
   
   <tr>
    <td width="908" height="10" valign="top"  align="left" ><!---------- gap---------></td>
   </tr>
   	
<!###########################################################################################>
<!-------------------------------table starts----------------------------------------------->
 <tr>
    <td width="908" height="20" valign="top"  align="left" >
<div align="center">
 <center>
  <table width="908" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr> 
  
   <!###########################################################################################>
<!-------------------------------table starts----------------------------------------------->
 <td width="737" height="20" valign="top"  align="justify" >
<div align="center">
 <center>
  <table width="737" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="737" height="10" valign="top"  align="left" ><font class=theading>Purpose </font></td>
   </tr>
    <tr>
    <td width="737" height="10" valign="top"  align="left" ></td>
   </tr>
   <tr>
 <td width="737" height="20" valign="top"  align="justify" > <font class=ttext>Economical general purpose Low pressure sprinkling Construction dewatering Submersible pumping Industrial wash down Construction, industrial & pump industries</font></td>
   </tr>
  </table>
 </center>
</div>
</td>
<!-------------------------------table endss----------------------------------------------->
<!###########################################################################################>

	<td width="21" height="10" valign="top"  align="left"><!--gap--></td>
<td width="150" height="10" valign="top"  align="left"><a href="http://www.ponaflex.co.kr/" target="_blank"><img src="shade_plogo6.jpg" width="150" height="80"border="0"></a></td>
   </tr>
   
  </table>
 </center>
</div>
</td>
   </tr>
<!-------------------------------table endss----------------------------------------------->
<!###########################################################################################>

      <tr>
    <td width="908" height="10" valign="top"  align="left" >
	
<!###########################################################################################>
<!-------------------------------table starts----------------------------------------------->

<div align="center">
 <center>
  <table width="908" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="500" height="10" valign="top"  align="left"><img src="ponaflatimg1.jpg" width="500" height="343" border="0"></td>
	<td width="20" height="10" valign="top"  align="left"></td>
	<td width="388" height="10" valign="top"  align="left">
	
<!###########################################################################################>
<!-------------------------------table starts----------------------------------------------->

<div align="center">
 <center>
  <table width="388" height="10" cellspacing="0" cellpadding="0" border="0">
    <tr>
    <td width="388" height="10" valign="top"  align="left" ><font class=theading>Application </font></td>
   </tr>
   <tr>
    <td width="388" height="10" valign="top"  align="left" ><!---------- gap---------></td>
   </tr>
   <!###########################################################################################>
<!-------------------------------table starts----------------------------------------------->
<tr>
    <td width="388" height="10" valign="top"  align="left" >
	
<div align="center">
 <center>
  <table width="388" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="20" height="10" valign="top"  align="left"><img src="bdot.jpg" width="20" height="20" border="0"></td>
	  <td width="10" height="10" valign="top"  align="left"></td>
	   <td width="358" height="10" valign="top"  align="left"><font class=ttext>Economical general purpose </font></td>
   </tr>
   <tr>
    <td width="20" height="10" valign="top"  align="left"><img src="bdot.jpg" width="20" height="20" border="0"></td>
	  <td width="10" height="10" valign="top"  align="left"></td>
	   <td width="358" height="10" valign="top"  align="left"><font class=ttext>Low pressure sprinkling </font></td>
   </tr>
   <tr>
    <td width="20" height="10" valign="top"  align="left"><img src="bdot.jpg" width="20" height="20" border="0"></td>
	  <td width="10" height="10" valign="top"  align="left"></td>
	   <td width="358" height="10" valign="top"  align="left"><font class=ttext>Construction dewatering </font></td>
   </tr>
   <tr>
    <td width="20" height="10" valign="top"  align="left"><img src="bdot.jpg" width="20" height="20" border="0"></td>
	  <td width="10" height="10" valign="top"  align="left"></td>
	   <td width="358" height="10" valign="top"  align="left"><font class=ttext>Submersible pumping </font></td>
   </tr>
   <tr>
    <td width="20" height="10" valign="top"  align="left"><img src="bdot.jpg" width="20" height="20" border="0"></td>
	  <td width="10" height="10" valign="top"  align="left"></td>
	   <td width="358" height="10" valign="top"  align="left"><font class=ttext>Industrial wash down </font></td>
   </tr>
    <tr>
    <td width="20" height="10" valign="top"  align="left"><img src="bdot.jpg" width="20" height="20" border="0"></td>
	  <td width="10" height="10" valign="top"  align="left"></td>
	   <td width="358" height="10" valign="top"  align="left"><font class=ttext>Construction, industrial & pump industries </font></td>
   </tr>
  </table>
 </center>
</div>
</td>
   </tr>
   <tr>
    <td width="388" height="10" valign="top"  align="left" ><!---------- gap---------></td>
   </tr>
    <tr>
    <td width="388" height="10" valign="top"  align="left" ><font class=theading>Features </font></td>
   </tr>
   <tr>
    <td width="388" height="10" valign="top"  align="left" ><!---------- gap---------></td>
   </tr>
    <!###########################################################################################>
<!-------------------------------table starts----------------------------------------------->
<tr>
    <td width="388" height="10" valign="top"  align="left" >
	
<div align="center">
 <center>
  <table width="388" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="20" height="10" valign="top"  align="left"><img src="bdot.jpg" width="20" height="20" border="0"></td>
	  <td width="10" height="10" valign="top"  align="left"></td>
	   <td width="358" height="10" valign="top"  align="left"><font class=ttext>Economical</font></td>
   </tr>
   <tr>
    <td width="20" height="10" valign="top"  align="left"><img src="bdot.jpg" width="20" height="20" border="0"></td>
	  <td width="10" height="10" valign="top"  align="left"></td>
	   <td width="358" height="10" valign="top"  align="left"><font class=ttext>Excellent performance on flat ground</font></td>
   </tr>
   <tr>
    <td width="20" height="10" valign="top"  align="left"><img src="bdot.jpg" width="20" height="20" border="0"></td>
	  <td width="10" height="10" valign="top"  align="left"></td>
	   <td width="358" height="10" valign="top"  align="left"><font class=ttext>2~7kgf/cm2 working pressure </font></td>
   </tr>
   <tr>
    <td width="20" height="10" valign="top"  align="left"><img src="bdot.jpg" width="20" height="20" border="0"></td>
	  <td width="10" height="10" valign="top"  align="left"></td>
	   <td width="358" height="10" valign="top"  align="left"><font class=ttext>Lightweight and compact for economical storage </font></td>
   </tr>
   <tr>
    <td width="20" height="10" valign="top"  align="left"><img src="bdot.jpg" width="20" height="20" border="0"></td>
	  <td width="10" height="10" valign="top"  align="left"></td>
	   <td width="358" height="10" valign="top"  align="left"><font class=ttext>100 meter continuous, coiled

 </font></td>
   </tr>
   
  </table>
 </center>
</div>
</td>
   </tr>
  
<!-------------------------------table endss----------------------------------------------->
<!###########################################################################################> 
<!-------------------------------table endss----------------------------------------------->
<!###########################################################################################>
  </table>
 </center>
</div>
<!-------------------------------table endss----------------------------------------------->
<!###########################################################################################>


	
	
	</td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------table endss----------------------------------------------->
<!###########################################################################################>


	
	
	
	
	
	
	</td>
   </tr>
     
   
   
      <tr>
    <td width="908" height="20" valign="top"  align="left" ><!---------- gap---------></td>
   </tr>
   
  
      <tr>
    <td width="908" height="10" valign="top"  align="left" >
	
<!###########################################################################################>
<!-------------------------------table starts----------------------------------------------->

<div align="center">
 <center>
  <table width="908" height="10" cellspacing="1" cellpadding="4" border="0">
   <tr>
    <td width="91" height="10" valign="middle"  align="center" class=tdh colspan="2"><font class=ttextwhite>Nomal Size</font></td>
	<td width="91" height="10" valign="middle"  align="center" class=tdh colspan="2"><font class=ttextwhite>I.D</font></td>
	<td width="91" height="10" valign="middle"  align="center"class=tdh colspan="2"><font class=ttextwhite>O.D	</font></td>
	<td width="91" height="10" valign="middle"  align="center" class=tdh colspan="2"><font class=ttextwhite>Std.Length</font></td>
	<td width="91" height="10" valign="middle"  align="center" class=tdh colspan="2"><font class=ttextwhite>W.P(at20�C)</font></td>
	
   </tr>
   <tr>
<td width="91" height="10" valign="middle"  align="center" class=tdha><font class=ttextwhite>mm </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdha> <font class=ttextwhite> inch</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdha> <font class=ttextwhite> mm</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdha> <font class=ttextwhite> inch</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdha> <font class=ttextwhite>mm </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdha> <font class=ttextwhite> inch</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdha> <font class=ttextwhite>m </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdha> <font class=ttextwhite> ft</font></td>
<td width="90" height="10" valign="middle"  align="center" class=tdha> <font class=ttextwhite>kg/cm<sup>2</sup> </font></td>
<td width="90" height="10" valign="middle"  align="center" class=tdha> <font class=ttextwhite>psi </font></td>
</tr>
<tr>
<td width="91" height="10" valign="middle"  align="center" class=tda><font class=ttext> 025</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>1 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext> 26.5</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext> 1.043</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>1.4</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>0.055 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext> 100</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>328 </font></td>
<td width="90" height="10" valign="middle"  align="center" class=tda> <font class=ttext> 7</font></td>
<td width="90" height="10" valign="middle"  align="center" class=tda> <font class=ttext> 100</font></td>
</tr>
<tr>
<td width="91" height="10" valign="middle"  align="center" class=tdb><font class=ttext> 032</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>1 1/4 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>33.5 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>1.319 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 1.4</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>0.055 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 100</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>328 </font></td>
<td width="90" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 6</font></td>
<td width="90" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>85 </font></td>
</tr>	
<tr>
<td width="91" height="10" valign="middle"  align="center" class=tda><font class=ttext> 040</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext> 	1 1/2</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>40.0 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>1.575 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>1.4 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext> 0.055</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext> 100</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext> 328</font></td>
<td width="90" height="10" valign="middle"  align="center" class=tda> <font class=ttext> 5</font></td>
<td width="90" height="10" valign="middle"  align="center" class=tda> <font class=ttext>70 </font></td>
</tr>	
<tr>
<td width="91" height="10" valign="middle"  align="center" class=tdb><font class=ttext>050 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 2</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>52.0 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>2.047 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 1.4</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 0.055</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>100 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 328</font></td>
<td width="90" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>4.5	 </font></td>
<td width="90" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>65 </font></td>
</tr>	<tr>
<td width="91" height="10" valign="middle"  align="center" class=tda><font class=ttext> 065</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext> 	2 1/2</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>65.0 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext> 2.559</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>1.5 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext> 0.059</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>100 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>328 </font></td>
<td width="90" height="10" valign="middle"  align="center" class=tda> <font class=ttext>4 </font></td>
<td width="90" height="10" valign="middle"  align="center" class=tda> <font class=ttext>55 </font></td>
</tr>	<tr>
<td width="91" height="10" valign="middle"  align="center" class=tdb><font class=ttext>075 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 3</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>77.0 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 3.031</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 1.5</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>0.059 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 100</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>328</font></td>
<td width="90" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>4 </font></td>
<td width="90" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>55 </font></td>
</tr>	<tr>
<td width="91" height="10" valign="middle"  align="center" class=tda><font class=ttext> 100</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>4 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>103.0 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext> 4.055</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>1.5	 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>0.059 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>100 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>328</font></td>
<td width="90" height="10" valign="middle"  align="center" class=tda> <font class=ttext>4 </font></td>
<td width="90" height="10" valign="middle"  align="center" class=tda> <font class=ttext>55 </font></td>
</tr>	<tr>
<td width="91" height="10" valign="middle"  align="center" class=tdb><font class=ttext>125 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 5</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>128.0 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 5.039</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>1.8 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>0.071 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 100</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 328</font></td>
<td width="90" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>3 </font></td>
<td width="90" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 45</font></td>
</tr>
	<tr>
<td width="91" height="10" valign="middle"  align="center" class=tda><font class=ttext> 150</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>6 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext> 153.0</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>6.024 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>	1.8 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>0.071 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>100 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>328 </font></td>
<td width="90" height="10" valign="middle"  align="center" class=tda> <font class=ttext>3 </font></td>
<td width="90" height="10" valign="middle"  align="center" class=tda> <font class=ttext>45 </font></td>
</tr>	
<tr>
<td width="91" height="10" valign="middle"  align="center" class=tdb><font class=ttext> 200</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>8	 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>205.0 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>8.150 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>2.1	 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>0.083 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>100 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>328 </font></td>
<td width="90" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>3	 </font></td>
<td width="90" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>45	 </font></td>
</tr>																													<tr>
<td width="91" height="10" valign="middle"  align="center" class=tda><font class=ttext> 250</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>10 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext> 252.2</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext> 10.197</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>2.3	 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext>0.091 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext> 165</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tda> <font class=ttext> 100</font></td>
<td width="90" height="10" valign="middle"  align="center" class=tda> <font class=ttext>2 </font></td>
<td width="90" height="10" valign="middle"  align="center" class=tda> <font class=ttext>30 </font></td>
</tr>								
					
	<tr>
<td width="91" height="10" valign="middle"  align="center" class=tdb><font class=ttext>300 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>12 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 302.0</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>12.126 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 2.5</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext>0.098 </font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 165</font></td>
<td width="91" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 100</font></td>
<td width="90" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 2</font></td>
<td width="90" height="10" valign="middle"  align="center" class=tdb> <font class=ttext> 30</font></td>
</tr>																																									
  </table>
 </center>
</div>
<!-------------------------------table endss----------------------------------------------->
<!###########################################################################################>


	
	
	
	
	
	
	</td>
   </tr> 
   
   
   
   
   
   
   
   
   
    <tr>
    <td width="908" height="10" valign="top"  align="left" ><!-------------------------------image and text starts------------------------------------------>
	<div align="center">
 <center>
  <table width="908" height="10" cellspacing="0" cellpadding="0" border="0">

  <tr>
    <td width="908" height="10" valign="top"  align="center"><!--gap--></td>
   
   </tr>
   <tr>
    <td width="908" height="10" valign="top"  align="right"><a href="products.php"><img src="linkimg.gif" width="300" height="20" border="0"></a></td>
   
   </tr>
  </table>
 </center>
</div>
<!-------------------------------image and text endss---------------------------------------></td>
   </tr> 
   <!------------------------working space ends here------------------>

  
    
   
 <!%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%1st prodtuct ends%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%>
   
     
   
   
   
   
   
   
   
   
   
   <!------------------dont touch below code------------------------->
   <tr>
    <td width="908" height="20" valign="top"  align="left" ><!----------bottom gap---------></td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------logo name and links endss--------------------------------------->
<!###########################################################################################></td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------logo name and links endss--------------------------------------->
<!###########################################################################################><!----------------------dont touch the below code ends--------------------->
</td>
   </tr>
      <tr>
    <td width="1004" height="40" valign="top"  align="left"><!-----------gap starts--------------></td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------middle portion shadow endss--------------------------------------->
<!###########################################################################################></td>
   </tr>
   <tr>
    <td width="100%" height="10" valign="top"  align="left"><!-------------------------------logo name and links starts------------------------------------>
<div align="center">
<center>
<table width="948" height="29" cellspacing="0" cellpadding="0" border="0">
<tr>
<td width="948" height="29" valign="top" align="left"><img src="scrollhead.png" width="197" height="29" border="0"></td>
</tr>
</table>
</center>
</div>
<!-------------------------------logo name and links endss--------------------------------------->


<!-------------------------------logo name and links starts------------------------------------>
<div align="center">
<center>
<table width="982" height="141" cellspacing="0" cellpadding="0" border="0" STYLE="background-image: url(scrollbg.png); background-position: bottom center; bgproperties: fixed; background-repeat:repeat-y">
<tr>
<td width="982" height="5" valign="top" align="left" ></td>
</tr>
<tr>
<td width="982" height="111" valign="top" align="left" ><!-------------------------------logo name and links starts------------------------------------------><div align="center">
<center>
<table width="982" height="111" cellspacing="0" cellpadding="0" border="0">
<tr>
<td width="17" height="111" valign="top" align="left"></td>
<td width="948" height="111" valign="middle" align="left" class=box><!-------------------------------logo name and links starts------------------------------------------><div align="center">
<center>
<table width="948" height="109" cellspacing="0" cellpadding="0" border="0">
<tr>
<td width="32" height="109" valign="top" align="left"><img src="scrollleft.jpg" width="32" height="109" border="0"></td>
<td width="883" height="109" valign="middle" align="left">
<table width="883" height="109" cellspacing="0" cellpadding="0" border="0">
<tr>
<td width="32" height="20" valign="top" align="left"></td>
</tr>
<tr>
<td width="32" height="81" valign="top" align="left" valign="bottom">

<link href="./imageslider.css" type="text/css" rel=stylesheet> <script language="javascript" src="./imageslider.js"></script>
<script language="javascript" src="./imageslidercfg.js"></script>

<!-- END -->
<!-- Please insert the div below to your Web page where you would -->
<!-- like to include the menu. --> <div id="Slider1_div" style="width:883px;height:80px;"></div>
<script language="javascript">



function CISlider1(ipa){
if(!(window.Slider1cfg)){eval('window.Slider1cfg=new Array();');};
Slider1cfg[Slider1cfg.length]=ipa;};
function InitSlider1(){
if (!window.Bmaf){setTimeout('InitSlider1()',350);return;};
new BXae('Slider1_div',883,80,1,39,12,0,'#E6F4FF',Slider1cfg,6,6);};
InitSlider1();
</script>
</td>
</tr>
<tr>
<td width="32" height="8" valign="top" align="left"></td>
</tr>
</table>
 </td>
<td width="32" height="109" valign="top" align="left"><img src="scrollright.jpg" width="32" height="109" border="0"></td>
</tr>
</table>
</center>
</div>
<!-------------------------------logo name and links endss---------------------------------------></td>
<td width="17" height="111" valign="top" align="left"></td>
</tr>
</table>
</center>
</div>
<!-------------------------------logo name and links endss---------------------------------------></td>
</tr>
<tr>
<td width="982" height="25" valign="top" align="center"><img src="scrollbottom.jpg" width="948" height="25" border="0"></td>
</tr>
</table>
</center>
</div>
<!-------------------------------logo name and links endss--------------------------------------->
</td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------table endss----------------------------------------------->
<!###########################################################################################>



<!###########################################################################################>
<!-------------------------------logo name and links starts------------------------------------------>
<div align="center">
 <center>
  <table width="100%" height="1" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="100%" height="2" valign="top"  align="left"  class=dblue></td>
   </tr>
   <tr>
    <td width="100%" height="1" valign="top"  align="left"  class=blue></td>
   </tr>
   <tr>
    <td width="100%" height="80" valign="top"  align="left"  class=blue1><!-------------------------------logo name and links starts------------------------------------------>
	<div align="center">
 <center>
  <table width="948" height="10" cellspacing="0" cellpadding="0" border="0">
  <tr>
  <td width="197" height="10" valign="top"  align="left">
  
<!###########################################################################################>
<!-------------------------------table 1 st td starts----------------------------------------------->

<div align="center">
 <center>
  <table width="197" height="10" cellspacing="0" cellpadding="0" border="0">
  <tr>
   
    <td width="197" height="10" valign="top"  align="left">
	
<!###########################################################################################>
<!-------------------------------table text for 1 st td starts----------------------------------------------->

<div align="center">
 <center>
  <table width="197" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="197" height="25" valign="top"  align="left"><!--gap--></td>
   </tr>
  
	
<!###########################################################################################>
<!-------------------------------tableofr qlink only starts----------------------------------------------->
 <tr>
    <td width="197" height="10" valign="top"  align="left">
<div align="center">
 <center>
  <table width="197" height="8" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="197" height="8" valign="top"  align="left"><a href="index.php"><font class=tbotlinks2>Home</font></a></td>
   </tr>
    <tr>
    <td width="197" height="8" valign="top"  align="left"><a href="aboutus.php"><font class=tbotlinks2>Profile</font></a></td>
   </tr>
    <tr>
    <td width="197" height="8" valign="top"  align="left"><a href="products.php"><font class=tbotlinks>Products</font> </a>  </td>
   </tr>
    <tr>
    <td width="197" height="8" valign="top"  align="left"><a href="contactus.php"><font class=tbotlinks2>Contact us</font></a></td>
   </tr>
  </table>
 </center>
</div>

	</td>
   </tr>
<!-------------------------------table for qlink only endss----------------------------------------------->
<!###########################################################################################>
 <tr>
    <td width="197" height="35" valign="top"  align="left"><!--gap--></td>
   </tr>
    <tr>
    <td width="197" height="1" valign="top"  align="left"><img src="hdottedline.gif" width="174" height="1" border="0"></td>
   </tr>
    <tr>
    <td width="197" height="7" valign="top"  align="left"><!--gap--></td>
   </tr>
    <tr>
    <td width="197" height="10" valign="top"  align="left"><font class=tbotlinks2><b><u>Alfaflex all product pdf</b></u></font></td>
   </tr>
     <tr>
    <td width="197" height="3" valign="top"  align="left"><!--gap--></td>
   </tr>
    <tr>
    <td width="197" height="10" valign="top"  align="left"><a href="egtdubaialfaflex.pdf"  target="_blank"><img src="downloadbutton.png" width="143" height="75" border="0"></a></td>
   </tr>
    <tr>
    <td width="197" height="3" valign="top"  align="left"><!--gap--></td>
   </tr>

   <tr>
    <td width="197" height="30" valign="top"  align="left"><!--gap--></td>
   </tr>
     <tr>
    <td width="197" height="10" valign="top"  align="left"><font class=tbotlinks2><b><u>Emmaflex all product pdf</b></u></font></td>
   </tr>
    <tr>
    <td width="197" height="3" valign="top"  align="left"><!--gap--></td>
   </tr>
     <tr>
    <td width="197" height="10" valign="top"  align="left"><a href="emmaflex_products.pdf"  target="_blank"><img src="downloadbutton.png" width="143" height="75" border="0"></a></td>
   </tr>
   
   
    <tr>
    <td width="197" height="3" valign="top"  align="left"><!--gap--></td>
   </tr>

   <tr>
    <td width="197" height="30" valign="top"  align="left"><!--gap--></td>
   </tr>
     <tr>
    <td width="197" height="10" valign="top"  align="left"><font class=tbotlinks2><b><u>Aeroquip Distributorship Letter </b></u></font></td>
   </tr>
    <tr>
    <td width="197" height="3" valign="top"  align="left"><!--gap--></td>
   </tr>
     <tr>
    <td width="197" height="10" valign="top"  align="left"><a href="eaton_distributor_letter.pdf"  target="_blank"><img src="downloadbutton.png" width="143" height="75" border="0"></a></td>
   </tr>
   </table>
 </center>
</div>
<!-------------------------------table text for 1st td endss----------------------------------------------->
<!###########################################################################################>
	</td>
  </tr>
    </table>
 </center>
</div>
  </td>
<!-------------------------------table  1 st td endss----------------------------------------------->
<!###########################################################################################>

<td width="10" height="10" valign="top"  align="left"><!--gap--> </td>
<td width="741" height="10" valign="top"  align="left"> 
<!###########################################################################################>
<!-------------------------------table starts----------------------------------------------->
<div align="center">
 <center>
  <table width="741" height="3" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="741" height="3" valign="top"  align="left"><!--gap--></td>
   </tr>
    
	<!###########################################################################################>
<!-------------------------------table 2nd tdstarts----------------------------------------------->
 <tr>
    <td width="741" height="3" valign="top"  align="left">
<div align="center">
 <center>
  <table width="741" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="1" height="10" valign="top"  align="left">
	<!###########################################################################################>
<!-------------------------------table starts----------------------------------------------->
<div align="center">
 <center>
  <table width="1" height="10" cellspacing="0" cellpadding="0" border="0">
    <tr>
    <td width="1" height="5" valign="top"  align="left"></td>
   </tr>
   <tr>
    <td width="1" height="10" valign="top"  align="left">
	<!###########################################################################################>
<!-------------------------------table starts----------------------------------------------->
<div align="center">
 <center>
  <table width="1" height="590" cellspacing="0" cellpadding="0" border="0"STYLE="background-image: url(vdottedline3.gif); background-position: top center; bgproperties: fixed; background-repeat:repeat-y">
   <tr>
    <td width="1" height="10" valign="top"  align="left"></td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------table endss----------------------------------------------->
<!###########################################################################################>
	</td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------table endss----------------------------------------------->
<!###########################################################################################>
	</td>
	  <td width="740" height="10" valign="top"  align="left">
	  <!###########################################################################################>
<!-------------------------------table for text nd gap starts----------------------------------------------->
<div align="center">
 <center>
  <table width="740" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="10" height="10" valign="top"  align="left"><!--gap---></td>
 <!###########################################################################################>
<!-------------------------------table for text starts----------------------------------------------->
 <td width="730" height="10" valign="top"  align="left">
<div align="center">
 <center>
  <table width="730" height="10" cellspacing="0" cellpadding="0" border="0">
  
	<!###########################################################################################>
<!-------------------------------table row1 starts----------------------------------------------->
 <tr>
    <td width="730" height="10" valign="top"  align="left">
<div align="center">
 <center>
  <table width="730" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="730" height="10" valign="top"  align="left"><font class=tbotlinks2> <b><u>PRODUCTS</u></b></font></td>
   </tr>
   
    
	<!###########################################################################################>
<!-------------------------------table divisions of  row1 starts----------------------------------------------->
 <tr>
    <td width="730" height="10" valign="top"  align="left">
<div align="center">
 <center>
  <table width="730" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="159" height="10" valign="top"  align="left">
	<!###########################################################################################>
<!-------------------------------table alfaflex starts----------------------------------------------->
<div align="center">
 <center>
  <table width="159" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="159" height="10" valign="top"  align="left" colspan="3"><!--top gap--></td>
   </tr>
   <tr>
    <td width="56" height="10" valign="top"  align="left"><a href="petrolumhose.php"><img src="qlogo1.jpg" width="56" height="18" border="0"></a></td>
	 <td width="7" height="10" valign="top"  align="left"><!--gap--></td>
	  <td width="96" height="10" valign="top"  align="left"><a href="petrolumhose.php"><font class=tbotlinks2>ALFAFLEX</font></a></td>
   </tr>
     <tr>
    <td width="56" height="5" valign="top"  align="left" colspan="3"><!--gap--></td>
	   </tr>
    <tr>
    <td width="56" height="10" valign="top"  align="left" colspan="3"><a href="petrolumhose.php"><font class=tbotlinks2>Petrolum Hose</font></a></td>
	   </tr>
	  
    <tr>
    <td width="56" height="10" valign="top"  align="left" colspan="3"><a href="waterhose.php"><font class=tbotlinks2>Water Hose</font></a></td>
	   </tr>
	  
    <tr>
    <td width="56" height="10" valign="top"  align="left" colspan="3"><a href="steamhose.php"><font class=tbotlinks2>Steam Hose</font></a></td>
	   </tr>
	     
    <tr>
    <td width="56" height="10" valign="top"  align="left" colspan="3"><a href="airhose.php"><font class=tbotlinks2>Air Hose</font></a></td>
	   </tr>
	   
    <tr>
    <td width="56" height="10" valign="top"  align="left" colspan="3"><a href="materialhose.php"><font class=tbotlinks2>Material Hose
</font></a></td>
	   </tr>
	 
    <tr>
    <td width="56" height="10" valign="top"  align="left" colspan="3"><a href="sandblasthose.php"><font class=tbotlinks2>Sand Blast Hose
</font></a></td>
	   </tr>
	 
    <tr>
    <td width="56" height="10" valign="top"  align="left" colspan="3"><a href="chemicalhose.php"><font class=tbotlinks2>Chemical Hose
</font></a></td>
	   </tr>
	   
    <tr>
    <td width="56" height="10" valign="top"  align="left" colspan="3"><a href="foodhose.php"><font class=tbotlinks2>Food Hose
</font></a></td>
	   </tr>
	  
    <tr>
    <td width="56" height="10" valign="top"  align="left" colspan="3"><a href="mudhose.php"><font class=tbotlinks2>Mud Hose
</font></a></td>
	   </tr>
  </table>
 </center>
</div>
<!-------------------------------table  alfaflex endss----------------------------------------------->
<!###########################################################################################>
	
	
	</td>
	
	<!###########################################################################################>
<!-------------------------------table emmflex ,line,gap starts----------------------------------------------->
<td width="207" height="10" valign="top"  align="left">
<div align="center">
 <center>
  <table width="207" height="10" cellspacing="0" cellpadding="0" border="0">
   
   <tr>
    <td width="1" height="10" valign="top"  align="left"><img src="vdottedline2.gif" width="1" height="191" border="0"></td>
	 <td width="10" height="10" valign="top"  align="left"></td>
	  <td width="196" height="10" valign="top"  align="left">
	  <!###########################################################################################>
<!-------------------------------table emmflex starts----------------------------------------------->
<div align="center">
 <center>
  <table width="196" height="10" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td width="196" height="10" valign="top"  align="left" colspan="3"><!--top gap--></td>
   </tr>
  <tr>
    <td width="56" height="10" valign="top"  align="left"><a href="hydrolichose1.php"><img src="emmaflexbottomlogo.jpg" width="56" height="18" border="0"></a></td>
	 <td width="10" height="10" valign="top"  align="left"><!--gap--></td>
	  <td width="130" height="10" valign="top"  align="left"><a href="hydrolichose1.php"><font class=tbotlinks2>EMMAFLEX</font></a></td>
   </tr>
    <tr>
    <td width="196" height="5" valign="top"  align="left" colspan="3"><!--gap--></td>
	   </tr>
	    <tr>
    <td width="196" height="10" valign="top"  align="left" colspan="3"><a href="hydrolichose1.php"><font class=tbotlinks2>Hydraulic Hose,EN 853 1SN</font></a></td>
	   </tr>
	    <tr>
    <td width="196" height="10" valign="top"  align="left" colspan="3"><a href="hydrolichose2.php"><font class=tbotlinks2>Hydraulic Hose,EN 853 2SN</font></a></td>
	   </tr>
	    <tr>
    <td width="196" height="10" valign="top"  align="left" colspan="3"><a href="hydrolichose3.php"><font class=tbotlinks2>Hydraulic Hose,EN 856 4SP</font></a></td>
	   </tr>
	   <tr>
    <td width="196" height="10" valign="top"  align="left" colspan="3"><a href="hydrolichose4.php"><font class=tbotlinks2>Hydraulic Hose,EN 856 4SH</font></a></td>
	   </tr>
  </table>
 </center>
</div>
<!-------------------------------table emmflex endss----------------------------------------------->
<!###########################################################################################>
	  </td>
   </tr>
  </table>
 </center>
</div>
</td>
<!-------------------------------table emmflex,line,gap endss----------------------------------------------->
<!###########################################################################################>
	
	
	<!###########################################################################################>
<!-------------------------------table windlass,line,gap starts----------------------------------------------->
<td width="185" height="10" valign="top"  align="left">
<div align="center">
 <center>
  <table width="185" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="1" height="10" valign="top"  align="left"><img src="vdottedline2.gif" width="1" height="191" border="0"></td>
	   <td width="10" height="10" valign="top"  align="left"></td>
	    
		  <!###########################################################################################>
<!-------------------------------table starts----------------------------------------------->
  <td width="174" height="10" valign="top"  align="left">
<div align="center">
 <center>
  <table width="174" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="174" height="10" valign="top"  align="left" colspan="3"><!--topgap--></td>
   </tr>
    <tr>
    <td width="56" height="10" valign="top"  align="left"><a href="hammerunion.php"><img src="windlassbottomlogo.jpg" width="56" height="18" border="0"></a></td>
	 <td width="10" height="10" valign="top"  align="left"><!--gap--></td>
	  <td width="109" height="10" valign="top"  align="left"><a href="hammerunion.php"><font class=tbotlinks2>WINDLASS</font></a></td>
   </tr>
    <tr>
    <td width="174" height="5" valign="top"  align="left" colspan="3"><!--gap--></td>
	   </tr>
     <tr>
    <td width="174" height="10" valign="top"  align="left" colspan="3"><a href="hammerunion.php"><font class=tbotlinks2>Hammer-Unions</font></a></td>
	   </tr>
	     <tr>
    <td width="174" height="10" valign="top"  align="left" colspan="3"><a href="ringjoint.php"><font class=tbotlinks2>Ring Joint Gaskets</font></a></td>
   </tr>
     <tr>
    <td width="174" height="10" valign="top"  align="left"  colspan="3"><a href="flanges.php"><font class=tbotlinks2>Flanges, Tees & Crosses</font></a></td>
   </tr>
    <tr>
    <td width="174" height="10" valign="top"  align="left" colspan="3"><a href="swivel.php"><font class=tbotlinks2>Swivel Joints</font></a></td>
   </tr>
     <tr>
    <td width="174" height="10" valign="top"  align="left" colspan="3"><a href="pupjoints.php"><font class=tbotlinks2>Pup Joints & Crossovers</font></a></td>
   </tr>
  </table>
 </center>
</div>
 </td>
<!-------------------------------table endss----------------------------------------------->
<!###########################################################################################>
		 
   </tr>
  </table>
 </center>
</div>
</td>
<!-------------------------------table windlass,line,gap endss----------------------------------------------->
<!###########################################################################################>
	
	<td width="179" height="10" valign="top"  align="left">
	<!###########################################################################################>
<!-------------------------------table klasflex,line,gap starts----------------------------------------------->
<div align="center">
 <center>
  <table width="179" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="1" height="10" valign="top"  align="left"><img src="vdottedline2.gif" width="1" height="191" border="0"></td>
	 <td width="10" height="10" valign="top"  align="left"></td>
	  <td width="168" height="10" valign="top"  align="left">
	  <!###########################################################################################>
<!-------------------------------table text starts----------------------------------------------->
<div align="center">
 <center>
  <table width="168" height="10" cellspacing="0" cellpadding="0" border="0">
    <tr>
    <td width="168" height="10" valign="top"  align="left" colspan="3"><!--topgap--></td>
   </tr>
    <tr>
    <td width="56" height="10" valign="top"  align="left"><a href="heavyduty.php"><img src="qlogo2.jpg" width="56" height="18" border="0"></a></td>
	 <td width="10" height="10" valign="top"  align="left"><!--gap--></td>
	  <td width="102" height="10" valign="top"  align="left"><a href="heavyduty.php"><font class=tbotlinks2>KLASFLEX</font></a></td>
   </tr>
    <tr>
    <td width="168" height="5" valign="top"  align="left" colspan="3"><!--gap--></td>
	   </tr>
    <tr>
    <td width="168" height="10" valign="top"  align="left" colspan="3"><a href="heavyduty.php"><font class=tbotlinks3>Heavy Duty  Suction Hose</font></a></td>
   </tr>
    <tr>
    <td width="168" height="10" valign="top"  align="left" colspan="3"><a href="springhose.php"><font class=tbotlinks2> Spring Hose</font></a></td>
   </tr>
    <tr>
    <td width="168" height="10" valign="top"  align="left" colspan="3"><a href="pvcreinforced.php"><font class=tbotlinks2> PVC Reinforced Hose</font></a></td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------table text endss----------------------------------------------->
<!###########################################################################################>
	  
	  </td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------table klasflex,line,gap endss----------------------------------------------->
<!###########################################################################################>
	
	</td>
   </tr>
  </table>
 </center>
</div>
</td>
   </tr>
<!-------------------------------table  divisions of  row1  endss----------------------------------------------->
<!###########################################################################################>
	
	
  </table>
 </center>
</div>
	</td>
   </tr>
<!-------------------------------table row1 endss----------------------------------------------->
<!###########################################################################################>
	

  
	<!###########################################################################################>
<!-------------------------------table row2 starts----------------------------------------------->
  <tr>
    <td width="730" height="1" valign="top"  align="left">
<div align="center">
 <center>
  <table width="730" height="1" cellspacing="0" cellpadding="0" border="0">
   <tr>
    
    <td width="730" height="8" valign="top"  align="left" colspan="4"><!--gap--></td>  
	
   </tr>
   <tr>
     <td width="356" height="1" valign="top"  align="left">
	 <!###########################################################################################>
<!-------------------------------table starts----------------------------------------------->
<div align="center">
 <center>
  <table width="356" height="10" cellspacing="0" cellpadding="0" border="0" STYLE="background-image: url(hdottedline222.gif); background-position: top center; bgproperties: fixed; background-repeat:repeat-X">
   <tr>
    <td width="356" height="10" valign="top"  align="left"></td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------table endss----------------------------------------------->
<!###########################################################################################>
	 </td>
	 <td width="23" height="1" valign="top"  align="left"></td>
	  <td width="351" height="1" valign="top"  align="left"><img src="hdottedline2.gif" width="346" height="1" border="0"></td>
	
	 
   </tr>
   
  </table>
 </center>
</div>
	</td>
   </tr>
<!-------------------------------table row2 endss----------------------------------------------->
<!####################################################################################>
 <!##################################################################################>
 <!#####################################################################################>
 <!############################################################################>
 <!#####################################################################################>
 <!#####################################################################################>
 <!#####################################################################################>
 
<!-------------------------------table row3 starts----------------------------------------------->
   <tr>
   
	 <td width="730" height="10" valign="top"  align="left">
<div align="center">
 <center>
  <table width="730" height="10" cellspacing="0" cellpadding="0" border="0">
   
    <tr>
    <td width="730" height="10" valign="top"  align="left">
	<!###########################################################################################>
<!-------------------------------table for eaton nd ponaflex starts----------------------------------------------->

<div align="center">
 <center>
  <table width="730" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="367" height="10" valign="top"  align="left">
	<!###########################################################################################>
<!-------------------------------table for GOODRICH GASKET starts----------------------------------------------->
<div align="center">
 <center>
  <table width="367" height="10" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td width="168" height="15" valign="top"  align="left" colspan="3"><!--gap--></td>
	   </tr>
   <tr>
    <td width="56" height="10" valign="top"  align="left"><a href="product13.php"><img src="goodbottomlogo.jpg" width="56" height="18" border="0"></a></td>
	<td width="10" height="10" valign="top"  align="left"></td>
	<td width="301" height="10" valign="top"  align="left"><a href="product13.php"><font class=tbotlinks2>GOODRICH GASKET</font></a></td>
   </tr>
    <tr>
    <td width="168" height="5" valign="top"  align="left" colspan="3"><!--gap--></td>
	   </tr>
     <tr>
    <td width="367" height="5" valign="top"  align="left" colspan="3"><a href="product13.php"><font class=tbotlinks3>Ring Type Joint Gasket</font></a></td>
	   </tr>
    
     <tr>
    <td width="367" height="5" valign="top"  align="left" colspan="3"><a href="product14.php"><font class=tbotlinks3>Spiral Wound Gasket & Low Stress Gasket</font></a></td>
	   </tr>
	     <tr>
    <td width="367" height="10" valign="top"  align="left" colspan="3"><a href="product15.php"><font class=tbotlinks3>Double Jacketed Gasket</font></a></td>
   </tr>
   <tr>
    <td width="367" height="10" valign="top"  align="left" colspan="3"><a href="product16.php"><font class=tbotlinks3>Kamm Profile Gasket</font></a></td>
   </tr>
    <tr>
    <td width="367" height="10" valign="top"  align="left" colspan="3"><a href="product17.php"><font class=tbotlinks3>Tanged Graphite Gasket & Sheets</font></a></td>
   </tr> 
   <tr>
    <td width="367" height="10" valign="top"  align="left" colspan="3"><a href="product18.php"><font class=tbotlinks3>Flange Insulating Kit</font></a></td>
   </tr>
   <tr>
    <td width="367" height="10" valign="top"  align="left" colspan="3"><a href="product19.php"><font class=tbotlinks3>Corrugated Metallatic Gasket With Flexible Graphite/Expanded PTFE</font></a></td>
   </tr>
	   
  </table>
 </center>
</div>
<!-------------------------------table for ponaflex endss----------------------------------------------->
<!###########################################################################################>
	</td>
	 <td width="1" height="10" valign="top"  align="left">	<img src="vdottedline22.gif" width="1" height="135" border="0"> </td>
	  <td width="9" height="10" valign="top"  align="left"><!--gap--></td>
	 <td width="353" height="10" valign="top"  align="left">
		<!###########################################################################################>
<!-------------------------------table for eaton aero starts----------------------------------------------->
<div align="center">
 <center>
  <table width="353" height="10" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td width="168" height="15" valign="top"  align="left" colspan="3"><!--gap--></td>
	   </tr>
   
    <tr>
    <td width="168" height="5" valign="top"  align="left" colspan="3"><!--gap--></td>
	   </tr>
     <tr>
    <td width="353" height="5" valign="top"  align="left" colspan="3"><a href="product20.php"><font class=tbotlinks3>Precision Machine Products</font></a></td>
	   </tr>
    
     <tr>
    <td width="353" height="5" valign="top"  align="left" colspan="3"><a href="product21.php"><font class=tbotlinks3>None-Asbestos Gaskets & Sheets</font></a></td>
	   </tr>
	     <tr>
    <td width="353" height="10" valign="top"  align="left" colspan="3"><a href="product22.php"><font class=tbotlinks3>Metal Bonded Rubber Gasket,'O' Ring & Sheets</font></a></td>
   </tr>
   <tr>
    <td width="353" height="10" valign="top"  align="left" colspan="3"><a href="product23.php"><font class=tbotlinks3>Monolithic Insulating Joint</font></a></td>
   </tr>
    <tr>
    <td width="353" height="10" valign="top"  align="left" colspan="3"><a href="product24.php"><font class=tbotlinks3>PTFE/Expanded PTFE Gaskets, PTFE Envelope, Seals & Sheets</font></a></td>
   </tr>
   <tr>
    <td width="353" height="10" valign="top"  align="left" colspan="3"><a href="product25.php"><font class=tbotlinks3>Studs & Nuts</font></a></td>
   </tr>
   <tr>
    <td width="353" height="10" valign="top"  align="left" colspan="3"><a href="product26.php"><font class=tbotlinks3>Packing Ropes & Rings</font></a></td>
   </tr>
    
	   
  </table>
 </center>
</div>
<!-------------------------------table for eaton aero endss----------------------------------------------->
<!###########################################################################################>
	 </td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------table  eaton nd ponaflex endss----------------------------------------------->
<!###########################################################################################>
	</td>
   </tr>
  </table>
 </center>
</div>
	</td>
   </tr>
<!-------------------------------table  row3 endss----------------------------------------------->









<!----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------->
<!###########################################################################################>
	<!-------------------------------table row3 starts----------------------------------------------->
   <tr>
	 <td width="730" height="10" valign="top"  align="left">
<div align="center">
 <center>
  <table width="730" height="10" cellspacing="0" cellpadding="0" border="0">
   
    <tr>
    <td width="730" height="10" valign="top"  align="left">
	<!###########################################################################################>
<!-------------------------------table for eaton nd ponaflex starts----------------------------------------------->
<table width="730" height="1" cellspacing="0" cellpadding="0" border="0">
   <tbody><tr>
    
    <td width="730" height="8" valign="top" align="left" colspan="4"><!--gap--></td>  
	
   </tr>
   <tr>
     <td width="356" height="1" valign="top" align="left">
	 <!--###########################################################################################-->
<!-------------------------------table starts----------------------------------------------->
<div align="center">
 <center>
  <table width="356" height="10" cellspacing="0" cellpadding="0" border="0" style="background-image: url(hdottedline222.gif); background-position: top center; bgproperties: fixed; background-repeat:repeat-X">
   <tbody><tr>
    <td width="356" height="10" valign="top" align="left"></td>
   </tr>
  </tbody></table>
 </center>
</div>
<!-------------------------------table endss----------------------------------------------->
<!--###########################################################################################-->
	 </td>
	 <td width="23" height="1" valign="top" align="left"></td>
	  <td width="351" height="1" valign="top" align="left"><img src="hdottedline2.gif" width="346" height="1" border="0"></td>
	
	 
   </tr>
   
  </tbody></table>
<div align="center">
 <center>
  <table width="730" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="367" height="10" valign="top"  align="left">
	<!###########################################################################################>
<!-------------------------------table for ponaflex starts----------------------------------------------->
<div align="center">
 <center>
  <table width="367" height="10" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td width="168" height="15" valign="top"  align="left" colspan="3"><!--gap--></td>
	   </tr>
   <tr>
    <td width="56" height="10" valign="top"  align="left"><a href="layflathose.php"><img src="ponaflexbottomlogo.jpg" width="56" height="18" border="0"></a></td>
	<td width="10" height="10" valign="top"  align="left"></td>
	<td width="301" height="10" valign="top"  align="left"><a href="layflathose.php"><font class=tbotlinks2>PONAFLEX</font></a></td>
   </tr>
    <tr>
    <td width="168" height="5" valign="top"  align="left" colspan="3"><!--gap--></td>
	   </tr>
     <tr>
    <td width="367" height="5" valign="top"  align="left" colspan="3"><a href="layflathose.php"><font class=tbotlinks3> 	Ponaflex Layflat Hose</font></a></td>
	   </tr>
    
     <tr>
    <td width="367" height="5" valign="top"  align="left" colspan="3"><a href="ponaflat.php"><font class=tbotlinks3> 	Ponaflat Standard Duty Layflat Hose</font></a></td>
	   </tr>
	     <tr>
    <td width="367" height="10" valign="top"  align="left" colspan="3"><a href="hydroflat.php"><font class=tbotlinks3> 	Hydroflat Medium Duty Layflat Hose</font></a></td>
   </tr>
   <tr>
    <td width="367" height="10" valign="top"  align="left" colspan="3"><a href="aqualinerheavy.php"> <font class=tbotlinks3>	Aqualiner Heavy Duty Layflat Hose</font></a></td>
   </tr>
    <tr>
    <td width="367" height="10" valign="top"  align="left" colspan="3"><a href="aqualinerus.php"><font class=tbotlinks3>Aqualiner US MSHA Accepted Heavy Duty Layflat Hose</font></a></td>
   </tr>
	   
  </table>
 </center>
</div>
<!-------------------------------table for ponaflex endss----------------------------------------------->

<!###########################################################################################>
	</td>
	
	 <td width="1" height="10" valign="top"  align="left">	<img src="vdottedline22.gif" width="1" height="135" border="0"> </td>
	  <td width="9" height="10" valign="top"  align="left"><!--gap--></td>
	 <td width="353" height="10" valign="top"  align="left">
		<!###########################################################################################>
<!-------------------------------table for eaton aero starts----------------------------------------------->

<div align="center">
 <center>
  <table width="353" height="10" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td width="168" height="15" valign="top"  align="left" colspan="3"><!--gap--></td>
	   </tr>
   <tr>
    <td width="56" height="10" valign="top"  align="left"><a href="product12.php"><img src="aerobottomlogo.jpg" width="56" height="18" border="0"></a></td>
	<td width="10" height="10" valign="top"  align="left"></td>
	<td width="287" height="10" valign="top"  align="left"><a href="product12.php"><font class=tbotlinks2>EATON AEROQUIP</font></a></td>
   </tr>
    <tr>
    <td width="168" height="5" valign="top"  align="left" colspan="3"><!--gap--></td>
	   </tr>
     <tr>
    <td width="353" height="5" valign="top"  align="left" colspan="3"><a href="product12.php"><font class=tbotlinks3> 	Connectors</font></a></td>
	   </tr>
    
     <tr>
    <td width="353" height="5" valign="top"  align="left" colspan="3"><a href="product12.php"><font class=tbotlinks3> 	Fittings</font></a></td>
	   </tr>
	     <tr>
    <td width="353" height="10" valign="top"  align="left" colspan="3"><a href="product12.php"><font class=tbotlinks3> 	Hydraulic Hose</font></a></td>
   </tr>
   <tr>
    <td width="353" height="10" valign="top"  align="left" colspan="3"><a href="product12.php"> <font class=tbotlinks3>	Hose Assembling</font></a></td>
   </tr>
    
	   
  </table>
 </center>
</div>
<!-------------------------------table for eaton aero endss----------------------------------------------->
<!###########################################################################################>
	 </td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------table  eaton nd ponaflex endss----------------------------------------------->
<!###########################################################################################>
	</td>
   </tr>
  </table>
 </center>
</div>
	</td>
   </tr>
<!-------------------------------table  row3 endss----------------------------------------------->
<!###########################################################################################>
	
	 
 <!###########################################################################################>
<!-------------------------------table row2 starts----------------------------------------------->
  <tr>
    <td width="730" height="1" valign="top"  align="left">
<div align="center">
 <center>
  <table width="730" height="1" cellspacing="0" cellpadding="0" border="0">
   <tr>
    
    <td width="730" height="8" valign="top"  align="left" colspan="4"><!--gap--></td>  
	
   </tr>
   <tr>
     <td width="356" height="1" valign="top"  align="left">
	 <!###########################################################################################>
<!-------------------------------table starts----------------------------------------------->
<div align="center">
 <center>
  <table width="356" height="10" cellspacing="0" cellpadding="0" border="0" STYLE="background-image: url(hdottedline222.gif); background-position: top center; bgproperties: fixed; background-repeat:repeat-X">
   <tr>
    <td width="356" height="10" valign="top"  align="left"></td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------table endss----------------------------------------------->
<!###########################################################################################>
	 </td>
	 <td width="23" height="1" valign="top"  align="left"></td>
	  <td width="351" height="1" valign="top"  align="left"><img src="hdottedline2.gif" width="346" height="1" border="0"></td>
	
	 
   </tr>
   
  </table>
 </center>
</div>
	</td>
   </tr>
<!-------------------------------table row2 endss----------------------------------------------->
<!###########################################################################################>
	
 

 <!###########################################################################################>
<!-------------------------------table  last row starts----------------------------------------------->
<tr>
	 <td width="730" height="1" valign="top"  align="left">
<div align="center">
 <center>
  <table width="730" height="10" cellspacing="0" cellpadding="0" border="0">
 
  
	<!###########################################################################################>
<!-------------------------------table  for goodall usa starts----------------------------------------------->
 <tr>
    <td width="730" height="10" valign="top"  align="left">
<div align="center">
 <center>
  <table width="730" height="10" cellspacing="0" cellpadding="0" border="0">
  <tr>
  <!###########################################################################################>
<!-------------------------------table starts----------------------------------------------->

  <td width="367" height="12" valign="top"  align="left">
<div align="center">
 <center>
  <table width="367" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="367" height="12" valign="top"  align="left" colspan="3"><!--gap---></td>
   </tr>
   <tr>
   <td width="56" height="10" valign="top"  align="left"><a href="product8.php"><img src="qlogo5.jpg" width="56" height="18" border="0"></a></td>
	<td width="17" height="10" valign="top"  align="left"></td>
	<td width="294" height="10" valign="top"  align="left"><a href="product8.php"><font class=tbotlinks2>GOODALL USA </font></a></td>
   </tr>
    <tr>
    <td width="367" height="5" valign="top"  align="left" colspan="3"><!--gap---></td>
   </tr>
    <tr>
   <td width="56" height="10" valign="top"  align="left"> <a href="product9.php"><img src="qlogo7.jpg" width="56" height="18" border="0"></a></td>
	<td width="17" height="10" valign="top"  align="left"></td>
	<td width="294" height="10" valign="top"  align="left"> <a href="product9.php"><font class=tbotlinks2>TRELLEBORG - FRANCE</font></a></td>
   </tr>
    <tr>
    <td width="367" height="5" valign="top"  align="left" colspan="3"><!--gap---></td>
   </tr>
      <tr>
   <td width="56" height="10" valign="top"  align="left"> <a href="product9.php"><a href="product10.php"><img src="qlogo8.jpg" width="56" height="18" border="0"></a></td>
	<td width="17" height="10" valign="top"  align="left"></td>
	<td width="294" height="10" valign="top"  align="left"> <a href="product10.php"><font class=tbotlinks2>FLEXONICS USA (U.S. HOSE CORPORATION)</font></a></td>
   </tr>
  </table>
 </center>
</div>
 </td>
<!-------------------------------table endss----------------------------------------------->
<!###########################################################################################>
 <td width="1" height="10" valign="top"  align="left"><img src="vdottedline3.gif" width="1" height="100" border="0"> </td>
   <td width="9" height="10" valign="top"  align="left"></td>

  <!###########################################################################################>
<!-------------------------------table starts----------------------------------------------->
  <td width="353" height="10" valign="top"  align="left">
<div align="center">
 <center>
  <table width="353" height="10" cellspacing="0" cellpadding="0" border="0">
     <tr>
    <td width="353" height="5" valign="top"  align="left"  >
	 <!###########################################################################################>
<!-------------------------------table for manntek starts----------------------------------------------->
<div align="center">
 <center>
  <table width="353" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="353" height="15" valign="top"  align="left" colspan="3"><!--gap--></td>
	   </tr>
  <tr>
    <td width="56" height="10" valign="top"  align="left"><a href="ddcoupling.php"><img src="manntekbottomlogo.jpg" width="56" height="18" border="0"></a></td>
	<td width="10" height="10" valign="top"  align="left"></td>
	<td width="287" height="10" valign="top"  align="left"><a href="ddcoupling.php"><font class=tbotlinks2>MANNTEK</font></a></td>
   </tr>
    <tr>
    <td width="353" height="5" valign="top"  align="left" colspan="3"><!--gap--></td>
	   </tr>
	    <tr>
    <td width="353 height="10" valign="top"  align="left" colspan="3"><a href="ddcoupling.php"><font class=tbotlinks3>	DD Couplings - dry disconnect couplings</font></a></td>
   </tr>
   <tr>
    <td width="353" height="10" valign="top"  align="left" colspan="3"><a href="dgcoupling.php"><font class=tbotlinks3> DG Couplings - dry gas couplings</font></a></td>
   </tr>
    <tr>
    <td width="353 height="10" valign="top"  align="left" colspan="3"><a href="sbcoupling.php"><font class=tbotlinks3> SB Couplings - safety break-away couplings</font></a></td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------table for manntek  endss----------------------------------------------->
<!###########################################################################################>
	</td>
	</tr>
	
	

  </table>
 </center>
</div>
</td>
</tr>
<!-------------------------------table endss----------------------------------------------->
<!###########################################################################################>
 
     </table>
 </center>
</div>
	</td>
   </tr>
<!-------------------------------table for good all usa endss----------------------------------------------->
<!###########################################################################################>

  </table>
 </center>
</div>
 </td>
	 </tr>
<!-------------------------------table rowendss----------------------------------------------->
<!###########################################################################################>
	
	

<!-------------------------------table row2 starts----------------------------------------------->
  <tr>
    <td width="730" height="1" valign="top"  align="left">
<div align="center">
 <center>
  <table width="730" height="1" cellspacing="0" cellpadding="0" border="0">
 <tr>
    
    <td width="730" height="8" valign="top"  align="left" colspan="4"><!--gap--></td>  
	
   </tr>
   <tr>
     <td width="356" height="1" valign="top"  align="left">
	 <!###########################################################################################>
<!-------------------------------table starts----------------------------------------------->
<div align="center">
 <center>
  <table width="356" height="10" cellspacing="0" cellpadding="0" border="0" STYLE="background-image: url(hdottedline222.gif); background-position: top center; bgproperties: fixed; background-repeat:repeat-X">
   <tr>
    <td width="356" height="10" valign="top"  align="left"></td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------table endss----------------------------------------------->
<!###########################################################################################>
	 </td>
	 <td width="23" height="1" valign="top"  align="left"></td>
	  <td width="351" height="1" valign="top"  align="left"><img src="hdottedline2.gif" width="346" height="1" border="0"></td>
	
	 
   </tr>
   
  </table>
 </center>
</div>
	</td>
   </tr>
<!-------------------------------table row2 endss----------------------------------------------->
<!###########################################################################################>
 <!###########################################################################################>
<!-------------------------------table row3 starts----------------------------------------------->
   <tr>
	 <td width="730" height="10" valign="top"  align="left">
<div align="center">
 <center>
  <table width="730" height="10" cellspacing="0" cellpadding="0" border="0">
<tr>
<td width="730" height="10" valign="top"  align="left">
	<!###########################################################################################>
<!-------------------------------table for other products  starts----------------------------------------------->
<div align="center">
 <center>
  <table width="730" height="10" cellspacing="0" cellpadding="0" border="0">
   <tr>
    <td width="367" height="10" valign="top"  align="left">
	<!###########################################################################################>
<!-------------------------------table starts----------------------------------------->
<div align="center">
 <center>
  <table width="367" height="10" cellspacing="0" cellpadding="0" border="0">
 
    <tr>
    <td width="367" height="12" valign="top"  align="left" colspan="7"><!--gap---></td>
   </tr>
	 <tr>
    <td width="56" height="10" valign="top"  align="left"><a href="product11.php"><img src="qlogo9a.jpg" width="56" height="18" border="0"></a></td>
	<td width="3" height="10" valign="top"  align="left"></td>
	<td width="56" height="10" valign="top"  align="left"><a href="product11.php"><img src="qlogo9c.jpg" width="56" height="18" border="0"></a></td>
	<td width="15" height="10" valign="top"  align="left"></td>
	<td width="178" height="10" valign="top"  align="left"><a href="product11.php"><font class=tbotlinks2>OTHER PRODUCTS</font></a></td>
	
	<td width="56" height="10" valign="top"  align="left"><!--a href="product11.php"><img src="qlogo9b.jpg" width="56" height="18" border="0"></a--></td>
	<td width="3" height="10" valign="top"  align="left"></td>
   </tr>
<tr>
    <td width="367" height="5" valign="top"  align="left" colspan="7" ><!--gap--></td>
	</tr>
<tr>
    <td width="367" height="5" valign="top"  align="left" colspan="7" >
	<!###########################################################################################>
<!-------------------------------table american block usa starts----------------------------------------------->
<div align="center">
 <center>
  <table width="367" height="10" cellspacing="0" cellpadding="0" border="0">
  <tr>
    <td width="56" height="10" valign="top"  align="left" ><a href="product7.php"><img src="qlogo3.jpg" width="56" height="18" border="0"></a></td>
	 <td width="20" height="10" valign="top"  align="left" ></td>
	 <td width="273" height="10" valign="top"  align="left" ><a href="product7.php"><font class=tbotlinks2>AMERICAN BLOCK USA</font></a></td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------table american block usa endss----------------------------------------------->
<!###########################################################################################>
</td>
</tr>	
  </table>
 </center>
</div>
<!-------------------------------table  endss----------------------------------------------->
<!###########################################################################################>
</td>
<td width="1" height="10" valign="top"  align="left">	<img src="vdottedline22.gif" width="1" height="82" border="0"> </td>
	  <td width="362" height="10" valign="top"  align="left"><!--gap--></td>
	
   </tr>
  </table>
 </center>
</div>
<!-------------------------------table  other products endss----------------------------------------------->
<!###########################################################################################>	
	

  </table>
 </center>
</div>
 </td>
<!-------------------------------table for text endss----------------------------------------------->
<!###########################################################################################>
	  
	  
	 
   </tr>
  </table>
 </center>
</div>
<!-------------------------------table for text nd gap endss----------------------------------------------->
<!###########################################################################################>
	  </td>
   </tr>
  </table>
 </center>
</div>
	</td>
   </tr>
<!-------------------------------table 2 nd tdendss----------------------------------------------->
<!###########################################################################################>
	
	

   
     
  </table>
 </center>
</div>
<!-------------------------------table endss----------------------------------------------->
<!###########################################################################################>
</td>
 



	

  </tr>
  <tr> 
  <td width="948" height="10" valign="top"  align="left" colspan="5"><!---bottom gap--></td>
  </tr>
 
  </table>
 </center>
</div>
<!-------------------------------logo name and links endss---------------------------------------></td>
   </tr>
  </table>
 </center>
</div>
<!-------------------------------logo name and links endss--------------------------------------->
<!###########################################################################################>


</body>
</html>
